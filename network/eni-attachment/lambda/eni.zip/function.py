import boto3
import json
import time

ssm = boto3.client('ssm')

def lambda_handler(event, context):
    print(event)

    # instanceId = event['detail']['requestParameters']['instanceId']
    instanceId = 'i-0d5f754fb97a32823'

    ssm.send_command(
        InstanceIds=[instanceId],
        DocumentName='eni-attachment',  # need to obtainde this value
        DocumentVersion='$LATEST',
        Comment='Attaching secondary network interface to instance'
    )
